﻿using System.ComponentModel;
using System.ComponentModel.Design;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Transactions;
using System.Xml.Serialization;

namespace WpfApp1
{

    enum Element // the pokemon elements to calculate super and under effective
    {
        fire,
        water,
        grass
    }

    class Charmander : Pokemon
    {

        public Charmander(string name) : base()
        {
            this.name = name;
            hp = 100;
            speed = 10;
            baseDmgFactor = 1.2;
            description = "roasted dino nuggy";
            atk1Name = "hug"; // removes the will of the other pokemon to fight and faints of fullfilness in life
            atk2Name = "belly bong"; // launches at the opposing pokemon at full speed clashing its stomach against theirs
            atk3Name = "Arson"; // powerfull fire attack, may cause self burn
            element = Element.fire;
            attack1Left = 25; // defining attacks left
            attack2Left = 3;
            attack3Left = 1;
        }

        public override int Attack1()
        {
            int damage = 100;

            if (attack1Left > 0) // checks if attacks left is above 0, subtracts 1 use, and returns damage
            {
                attack1Left--;
                return damage;
            }
            return 0; // I thought was better since attacks left never goes bellow 0
        }
        public override int Attack2()
        {
            int damage = 20;

            if (attack2Left > 0)
            {
                attack2Left--;
                return damage;
            }
            return 0;
        }

        public override int Attack3()
        {
            int damage = 40;

            if (attack3Left > 0)
            {
                attack3Left--;
                return damage;
            }
            return 0;
        }

    }
    class Squirtle : Pokemon
    {

        public Squirtle(string name) : base()
        {
            this.name = name;
            hp = 110;
            speed = 8;
            baseDmgFactor = 1.1;
            description = "cute water kj";
            atk1Name = "Water Splash";  // basic water attack
            atk2Name = "fidget spinner";    // they see it rolling, they hating
            atk3Name = "typhoon";       // oh, dang.
            element = Element.water;
            attack1Left = 25; // defining attacks left
            attack2Left = 10;
            attack3Left = 2;
        }

        public override int Attack1()
        {
            int damage = 10;

            if (attack1Left > 0) // same above reason
            {
                attack1Left--;
                return damage;
            }
            return 0;
        }

        public override int Attack2()
        {
            int damage = 15;

            if (attack2Left > 0)
            {
                attack2Left--;
                return damage;
            }
            return 0;
        }

        public override int Attack3()
        {
            int damage = 45;

            if (attack3Left > 0)
            {
                attack3Left--;
                return damage;
            }
            return 0;
        }
    }

    class Bulbasaur : Pokemon
    {

        public Bulbasaur(string name) : base()
        {
            this.name = name;
            hp = 99;
            speed = 7;
            baseDmgFactor = 1.0;
            description = "leafy boy";
            atk1Name = "Vine Whip";   // basic grass attack
            atk2Name = "allergen";   // causes user to be affected by a abstract allergy
            atk3Name = "Solar Beam";  // powerful grass move utilizing da sun to charge a tickling atek
            element = Element.grass;
            attack1Left = 30; // defining attacks left
            attack2Left = 15;
            attack3Left = 1;
        }

        public override int Attack1()
        {
            int damage = 12; // same above, above reason

            if (attack1Left > 0)
            {
                attack1Left--;
                return 0;
            }
            return damage;
        }

        public override int Attack2()
        {
            int damage = 25;

            if (attack2Left == 0)
            {
                attack2Left--;
                return 0;
            }
            return damage;
        }

        public override int Attack3()
        {
            int damage = 45;

            if (attack3Left > 0)
            {
                attack3Left--;
                return damage;

            }

            return 0;
        }
    }

    abstract class Pokemon // premade
    {
        public int attack1Left = 100;
        public int attack2Left = 100;
        public int attack3Left = 100;
        public string name = "Pokemon";
        public int hp = 1;
        public int speed = 1;
        public double baseDmgFactor = 1.0;
        public string description = "basic pokemon";
        public string atk1Name = "attack 1 name";
        public string atk2Name = "attack 2 name";
        public string atk3Name = "attack 3 name";

        public Element element = Element.fire;

        public abstract int Attack1();
        public abstract int Attack2();
        public abstract int Attack3();

        public void hit(int damage)
        {
            hp -= damage;
        }

        public bool isDead()
        {
            return hp <= 0;
        }
    }



    class Progam // premade
    {

        public const double ATK_STRONG = 2.0;
        public const double ATK_NEUTRAL = 1.0;
        public const double ATK_WEAK = 0.5;

        public static void doBattle(Pokemon p1, Pokemon p2, int attackNum)
        {
            int damage = 0;

            double baseDamageFactor = p1.baseDmgFactor;
            int atkDamage = 1;
            switch (attackNum)
            {
                case 1:
                    atkDamage = p1.Attack1();
                    break;
                case 2:
                    atkDamage = p1.Attack2();
                    break;
                case 3:
                    atkDamage = p1.Attack3();
                    break;
            }
            double elemDamage = rps(p1.element, p2.element);

            double totalDmg = (baseDamageFactor * atkDamage) * elemDamage;

            p2.hit(Convert.ToInt32(totalDmg));
        }

        public static double rps(Element e1, Element e2)
        {
            double value = 0.0;

            if (e1 == Element.fire)
            {
                switch (e2)
                {
                    case Element.fire:
                        value = ATK_NEUTRAL;
                        break;
                    case Element.water:
                        value = ATK_WEAK;
                        break;
                    case Element.grass:
                        value = ATK_STRONG;
                        break;
                }
            }
            else if (e1 == Element.water)
            {
                switch (e2)
                {
                    case Element.fire:
                        value = ATK_STRONG;
                        break;
                    case Element.water:
                        value = ATK_NEUTRAL;
                        break;
                    case Element.grass:
                        value = ATK_WEAK;
                        break;
                }
            }
            else // grass, although putting normal type element would be more beneficial as we may add additional types in the future
            {
                switch (e2)
                {
                    case Element.fire:
                        value = ATK_WEAK;
                        break;
                    case Element.water:
                        value = ATK_STRONG;
                        break;
                    case Element.grass:
                        value = ATK_NEUTRAL;
                        break;
                }
            }
            return value;
        }


        /*public static void Main(string[] args)
        {
            Random rnd = new Random(); // RNGG DUDD
            bool PokeChoice = true;
            // Initialize user pokemon as program is stewpid and doesnt realize i can do it at the bottom without it escaping somehow
            Pokemon p1 = new Squirtle("hi");

            while (PokeChoice == true) // loop to prevent user from misinputing, or choosing somthing nonexistent
            {
                Console.WriteLine("Choose your character: \n\n Squirtle [1] \n\n charmander [2] \n\n Bulbasaur [3]");
                switch (Console.ReadLine())
                {
                    case "1":
                        Console.WriteLine("Give your new fren a name: \n"); // overrides pokemon as to follow choice of user
                        p1 = new Squirtle(Console.ReadLine());
                        PokeChoice = false;
                        break;
                    case "2":
                        Console.WriteLine("Give your new fren a name: \n");
                        p1 = new Charmander(Console.ReadLine());
                        PokeChoice = false;
                        break;
                    case "3":
                        Console.WriteLine("Give your new fren a name: \n");
                        p1 = new Bulbasaur(Console.ReadLine());
                        PokeChoice = false;
                        break;
                    default:
                        Console.WriteLine("Error please choose between \n");
                        break;
                }
            }
            PokeChoice = true; // resets the bool for the loop, for future use
            Pokemon p2 = new Squirtle("hi");
            // Initialize the oponent pokemon just to be safe from errors
            while (PokeChoice == true) // loop to prevent user from misinputing, or choosing somthing nonexistent
            {
                Console.WriteLine("Choose the Opps pokemon: \n\n Squirtle [1] \n\n charmander [2] \n\n Bulbasaur [3]");
                switch (Console.ReadLine())
                {
                    case "1":
                        Console.WriteLine("Name your Opps: \n"); // overrides pokemon as to follow user choice
                        p2 = new Squirtle(Console.ReadLine());
                        PokeChoice = false;
                        break;
                    case "2":
                        Console.WriteLine("Name your Opps: \n");
                        p2 = new Charmander(Console.ReadLine());
                        PokeChoice = false;
                        break;
                    case "3":
                        Console.WriteLine("Name your Opps: \n");
                        p2 = new Bulbasaur(Console.ReadLine());
                        PokeChoice = false;
                        break;
                    default:
                        Console.WriteLine("Error please choose between \n");
                        break;
                }
            }
            PokeChoice = true; // resets the bool for the loop, for future use

            Console.WriteLine($"Battle Start!\n{p1.name} vs. {p2.name}\n"); // battle starts and outputs the user made names for the pokemon


            while (!p1.isDead() && !p2.isDead())
            {

                Console.WriteLine($"Your Turn!\n\n {p1.name}'s HP: {p1.hp}, {p2.name}'s HP: {p2.hp}\n"); // outputs HP for both pokemon
                while (PokeChoice == true)
                {
                    Console.WriteLine($"Choose an attack: \n1. {p1.atk1Name} \n2. {p1.atk2Name} \n3. {p1.atk3Name}"); // asks user to choose an atek
                    int choice = Convert.ToInt32(Console.ReadLine());



                    if (choice == 1)
                    {

                        // Player's attack's variations
                        Console.WriteLine($"{p1.name} uses {p1.atk1Name}!");
                        doBattle(p1, p2, choice);
                        PokeChoice = false;
                    }
                    else if (choice == 2)
                    {
                        Console.WriteLine($"{p1.name} uses {p1.atk2Name}!");
                        doBattle(p1, p2, choice);
                        PokeChoice = false;
                    }
                    else if (choice == 3)
                    {
                        Console.WriteLine($"{p1.name} uses {p1.atk3Name}!");
                        doBattle(p1, p2, choice);
                        PokeChoice = false;
                    }
                    else
                    {
                        // Ensure valid input
                        Console.WriteLine("Invalid choice. Try again.");

                    }
                }
                PokeChoice = true; // resets bool for future use
                                   // Check if opponent fainted after move, so it can't attack when already fainted
                if (p2.isDead())
                {
                    Console.WriteLine($"{p2.name} has fainted! You win!");
                    break;
                }

                // Computer's turn (AI chooses randomly)
                Random rand = new Random();

                while (PokeChoice == true) // Ensures valid input
                {
                    int computerChoice = rand.Next(1, 4);  // Random attack from 1 to 3

                    switch (computerChoice) // checks if attack has moves left. Can't let Bob make errors now.
                    {
                        case 1:
                            if (p2.attack1Left > 0)
                            {
                                PokeChoice = false;
                                Console.WriteLine($"{p2.name} uses {p2.atk1Name}!");
                                doBattle(p2, p1, 1);
                            }
                            break;

                        case 2:
                            if (p2.attack2Left > 0)
                            {
                                PokeChoice = false;
                                Console.WriteLine($"{p2.name} uses {p2.atk2Name}!");
                                doBattle(p2, p1, 2);
                            }
                            break;

                        case 3:
                            if (p2.attack3Left > 0)
                            {
                                PokeChoice = false;
                                Console.WriteLine($"{p2.name} uses {p2.atk3Name}!");
                                doBattle(p2, p1, 3);
                            }
                            break;
                        default:
                            break;
                    }

                }

                PokeChoice = true; // resets bool for future use



                // Checks if player fainted
                if (p1.isDead())
                {
                    Console.WriteLine($"{p1.name} has fainted! You lose!");
                    break;
                }
            }

            Console.WriteLine("Battle End!"); // tan tan tannnnnnnnnnnnnnnnnnnnnnnnnnnnnn (battle ends)
        } */

    }
}
