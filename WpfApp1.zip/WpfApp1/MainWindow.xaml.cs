﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

// to remember: Initiate(int idleFrames, string idleFileName, int attack1Frames, string attack1FileName, int attack2Frames,
// string attack2FileName, int attack3Frames, string attack3FileName, int faintFrames, string faintFileName, double speed)

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Progam prog;
        private Animation profAnimation;
        private DispatcherTimer timer;

        public MainWindow()
        {
            InitializeComponent();

            // Initialize the Animation instance for Prof
            profAnimation = new Animation();

            // Call the Initiate function with sample parameters
            profAnimation.Initiate(2, "ProffesorProf", 1, "ProffesorProf", 1, "ProffesorProf", 1, "ProffesorProf", 1, "ProffesorProf", 500);
            profAnimation.setMode(Animation.Modes.Idle);
        }



        private void txtName_TextChanged(object sender, TextChangedEventArgs e)
        {
           
        }


        private void rbATK1_Checked(object sender, RoutedEventArgs e)
        {

        }

      
        private void cmdSubmit_Click(object sender, RoutedEventArgs e)
        {
        }

      

        private void charChoice_Click(object sender, RoutedEventArgs e)
        {
            pokeBackDropImage.Visibility = Visibility.Visible;
        }

        private void bulbChoice_Click(object sender, RoutedEventArgs e)
        {
            pokeBackDropImage.Visibility = Visibility.Visible;
        }

        private void squirtChoice_Click(object sender, RoutedEventArgs e)
        {
            pokeBackDropImage.Visibility = Visibility.Visible;
        }
    }
}
